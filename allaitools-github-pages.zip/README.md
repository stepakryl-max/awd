# AllAITools static site

This is a GitHub Pages-ready copy of the supplied site. It has no build step.

## Publish with GitHub Pages

1. Put `index.html` at the root of a GitHub repository.
2. Push it to the repository's `main` branch.
3. In the repository, open **Settings → Pages** and publish from the `main` branch and `/(root)` folder.

The page keeps its existing external Tailwind, Google Fonts, and Font Awesome CDN links, so those visual assets require an internet connection. Saved bookmarks and submitted tools use the visitor's browser `localStorage`.
